import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { query, maxResults = 12 } = await req.json();
    
    // YouTube Data API v3 search
    // Using a public API key approach (users can add their own)
    const YOUTUBE_API_KEY = Deno.env.get('YOUTUBE_API_KEY');
    
    if (!YOUTUBE_API_KEY) {
      // Return mock data if no API key
      return new Response(JSON.stringify({ 
        videos: [],
        error: 'YouTube API key not configured. Please add YOUTUBE_API_KEY to secrets.'
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const searchQuery = `${query} farming agriculture tutorial`;
    const youtubeResponse = await fetch(
      `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(searchQuery)}&type=video&maxResults=${maxResults}&key=${YOUTUBE_API_KEY}&relevanceLanguage=en&safeSearch=strict`
    );

    if (!youtubeResponse.ok) {
      throw new Error(`YouTube API error: ${youtubeResponse.status}`);
    }

    const data = await youtubeResponse.json();
    
    // Get video details for duration and statistics
    const videoIds = data.items.map((item: any) => item.id.videoId).join(',');
    const detailsResponse = await fetch(
      `https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics&id=${videoIds}&key=${YOUTUBE_API_KEY}`
    );
    const detailsData = await detailsResponse.json();

    // Format the response
    const videos = data.items.map((item: any, index: number) => {
      const details = detailsData.items[index];
      const duration = details?.contentDetails?.duration || 'PT0S';
      const stats = details?.statistics || {};
      
      // Convert ISO 8601 duration to readable format
      const durationMatch = duration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
      const hours = durationMatch?.[1] || '0';
      const minutes = durationMatch?.[2] || '0';
      const seconds = durationMatch?.[3] || '0';
      const formattedDuration = hours !== '0' 
        ? `${hours}:${minutes.padStart(2, '0')}:${seconds.padStart(2, '0')}`
        : `${minutes}:${seconds.padStart(2, '0')}`;

      return {
        id: item.id.videoId,
        title: item.snippet.title,
        description: item.snippet.description,
        thumbnail: item.snippet.thumbnails.high?.url || item.snippet.thumbnails.default.url,
        channel: item.snippet.channelTitle,
        publishedAt: item.snippet.publishedAt,
        duration: formattedDuration,
        views: parseInt(stats.viewCount || '0'),
        likes: parseInt(stats.likeCount || '0'),
        url: `https://www.youtube.com/watch?v=${item.id.videoId}`
      };
    });

    return new Response(JSON.stringify({ videos }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in search-farming-videos function:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error',
      videos: []
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
